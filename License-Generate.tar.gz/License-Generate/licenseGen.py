#! /usr/bin/python

'''
Created on 2013-1-6

@author: ZHUZE
'''
import sys
import time
import subprocess
import des
import md5
import string
import get_hardwareid
import binascii
from Crypto.Cipher import AES
desKey="guofu123"
def encode(str,key):
    mode = AES.MODE_ECB
    decryptor = AES.new(key,mode)
    code = decryptor.encrypt(str)
    return code

if __name__ == "__main__":
    args=sys.argv
    c=args[1]
    mac = '%s::::' % c
    #print "mac:"+mac
    #output = open('/tmp/data', 'wb')
    #print decode(mac,'1234567890abcdef')
    ciphertext = encode(mac,'1234567890abcdef')
    #print '%s' % ciphertext
    #c = int(ciphertext,16)
    c = binascii.hexlify(ciphertext)
    #print "c:"+c
    m=''
    #name = get_hardwareid.get_hardwareid()
    while c:
        f=c[0:2]
        #n+= f+" "
        m+=binascii.unhexlify(f)
        c=c[2:]
    #print"c:"+c
    #name = m
    name = ciphertext
    deadline=args[2]
    vmamount=args[3]
    vmnum=string.atoi(vmamount)
    nameinfo=md5.strmd5(name)[0:4]
    #print "name:"+name
    print nameinfo
    if vmnum<10:
        vmamount="000"+vmamount
    elif vmnum<100:
        vmamount="00"+vmamount
    elif vmnum<1000:
        vmamount="0"+vmamount
    src=nameinfo+vmamount+deadline
    print src
    code=des.strdesen(src,desKey)
    print code
